-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 08-Jul-2019 às 19:49
-- Versão do servidor: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_defensoria`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `area_do_direito`
--

CREATE TABLE `area_do_direito` (
  `ID_DIREITO` int(30) NOT NULL,
  `NOME_DIREITO` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `area_do_direito`
--

INSERT INTO `area_do_direito` (`ID_DIREITO`, `NOME_DIREITO`) VALUES
(1, 'Civil'),
(2, 'Familia'),
(3, 'Consumidor'),
(4, 'Fazenda Publica'),
(5, 'Criminal');

-- --------------------------------------------------------

--
-- Estrutura da tabela `area_subdireito`
--

CREATE TABLE `area_subdireito` (
  `ID_SUBDIREITO` int(200) NOT NULL,
  `NOME_SUBDIREITO` varchar(300) NOT NULL,
  `ID_DIREITO` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `assistido`
--

CREATE TABLE `assistido` (
  `RG_ASS` int(9) DEFAULT NULL,
  `NOME_ASS` int(100) NOT NULL,
  `EMAIL_ASS` int(40) NOT NULL,
  `TELEFONE_ASS` int(14) NOT NULL,
  `SEXO` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `atendimento`
--

CREATE TABLE `atendimento` (
  `ID_ATENDIMENTO` int(225) NOT NULL,
  `MAT_FUNC` int(5) NOT NULL,
  `RG_ASS` int(9) NOT NULL,
  `ID_DIR` int(10) NOT NULL,
  `PRIORIDADE_ATENDIMENTO` varchar(10) NOT NULL,
  `COMENTARIO_ATENDIMENTO` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionario`
--

CREATE TABLE `funcionario` (
  `ID_FUNC` int(11) NOT NULL,
  `MAT_FUNC` int(5) NOT NULL,
  `ID_TIPO_FUNC` int(1) NOT NULL,
  `NOME_FUNC` varchar(100) NOT NULL,
  `SENHA_FUNC` varchar(50) NOT NULL,
  `HORA_EXPEDIENTE_FUNC` datetime NOT NULL,
  `INSTITUICAO_FUNC` varchar(40) NOT NULL,
  `DATA_CADASTRO_FUNC` datetime NOT NULL,
  `RG_FUNC` int(9) NOT NULL,
  `CPF_FUNC` int(11) NOT NULL,
  `EMAIL_FUNC` varchar(100) NOT NULL,
  `MATRICULA_INST_FUNC` int(10) NOT NULL,
  `ENDERECO_FUNC` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `funcionario`
--

INSERT INTO `funcionario` (`ID_FUNC`, `MAT_FUNC`, `ID_TIPO_FUNC`, `NOME_FUNC`, `SENHA_FUNC`, `HORA_EXPEDIENTE_FUNC`, `INSTITUICAO_FUNC`, `DATA_CADASTRO_FUNC`, `RG_FUNC`, `CPF_FUNC`, `EMAIL_FUNC`, `MATRICULA_INST_FUNC`, `ENDERECO_FUNC`) VALUES
(1, 12345, 1, 'Thiago Bastos', '827ccb0eea8a706c4c34a16891f84e7b', '0000-00-00 00:00:00', 'FAETERJ Rio', '2019-07-08 11:55:26', 129876543, 1213456789, 'bthiagos@gmail.com', 2147483647, 'Rua das Neves 127'),
(2, 11111, 2, 'Alfredo Souza', '12345', '0000-00-00 00:00:00', 'FAETERJ Rio', '2019-07-08 12:05:27', 129876543, 1213456789, 'alfredo@gmail.com', 2147483647, 'Rua das Neves 127'),
(3, 55555, 2, 'Paula Fernandes da Rosa', '827ccb0eea8a706c4c34a16891f84e7b', '0000-00-00 00:00:00', 'UFF', '2019-07-08 13:10:57', 0, 0, 'pf@pf.net', 0, '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_funcionario`
--

CREATE TABLE `tipo_funcionario` (
  `ID_TIPO_FUNC` int(11) NOT NULL,
  `CARGO_FUNC` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tipo_funcionario`
--

INSERT INTO `tipo_funcionario` (`ID_TIPO_FUNC`, `CARGO_FUNC`) VALUES
(1, 'Administrador'),
(2, 'Estagiário Contratado'),
(3, 'Estagiário Voluntário');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `area_do_direito`
--
ALTER TABLE `area_do_direito`
  ADD PRIMARY KEY (`ID_DIREITO`);

--
-- Indexes for table `atendimento`
--
ALTER TABLE `atendimento`
  ADD PRIMARY KEY (`ID_ATENDIMENTO`);

--
-- Indexes for table `funcionario`
--
ALTER TABLE `funcionario`
  ADD PRIMARY KEY (`ID_FUNC`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `atendimento`
--
ALTER TABLE `atendimento`
  MODIFY `ID_ATENDIMENTO` int(225) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `funcionario`
--
ALTER TABLE `funcionario`
  MODIFY `ID_FUNC` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
